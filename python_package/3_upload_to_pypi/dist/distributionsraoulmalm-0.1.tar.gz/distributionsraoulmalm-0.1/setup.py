from setuptools import setup

setup(name='distributionsraoulmalm',
      version='0.1',
      description='Gaussian distributions',
      packages=['distributionsraoulmalm'],
      zip_safe=False)
